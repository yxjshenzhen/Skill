# 爬虫模板库

------

为了方便大家使用，平台提供了一些示例爬虫模板供大家测试使用。

 - 腾讯新闻：[精准时间模板](https://github.com/gsh199449/spider/blob/master/examples/news.qq.com.json)，[自动探测时间模板](https://github.com/gsh199449/spider/blob/master/examples/news.qq.com_time_autodetect.json)
 - 诗词网：[诗词名句网](https://github.com/gsh199449/spider/blob/master/examples/www.shicimingju.com.json)
 - 中新网: [新闻抽取](https://github.com/gsh199449/spider/blob/master/examples/www.chinanews.com.json)
 - 网易新闻: [新闻抽取](https://github.com/gsh199449/spider/blob/master/examples/news.163.com.json)
 - 搜狐新闻：[搜狐](https://github.com/gsh199449/spider/blob/master/examples/news.sohu.com.json)，
 - 开源中国: [含有动态字段的抽取](https://github.com/gsh199449/spider/blob/master/examples/www.oschina.net.json)


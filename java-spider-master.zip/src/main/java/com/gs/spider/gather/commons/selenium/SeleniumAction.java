package com.gs.spider.gather.commons.selenium;

import org.openqa.selenium.WebDriver;

public interface SeleniumAction {
    void execute(WebDriver driver);
}

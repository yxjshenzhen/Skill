package com.gs.spider.model.async;

public enum State {INIT, RUNNING, STOP, FAIL}
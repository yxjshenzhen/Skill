package com.gs.spider.model.async;

/**
 * MsgType
 */
public enum MsgType {
    PING, ASK, REPLY, LOGIN, INFO, CALLBACK_REPLY, CALLBACK
}

package com.gs.spider.controller;

public class BaseController {

}

